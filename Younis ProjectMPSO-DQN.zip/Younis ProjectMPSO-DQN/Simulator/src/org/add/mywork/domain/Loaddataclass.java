package org.add.mywork.domain;


import java.util.ArrayList;
import java.util.List;

import org.fog.application.AppEdge;
import org.fog.application.AppLoop;
import org.fog.application.Application;
import org.fog.application.selectivity.FractionalSelectivity;
import org.fog.entities.Tuple;

public class Loaddataclass {
	

public static Application createApplication(String appId, int clientId){
		
		Application application = Application.createApplication(appId, clientId);  
		
		 
		application.addAppModule("client", 10);  
		application.addAppModule("datascheduler", 10);  
		application.addAppModule("gatewaymodule", 10);  
		
		 
		
	
	    application.addAppEdge("enduser", "client", 3000, 500, "enduser", Tuple.UP, AppEdge.SENSOR);
		application.addAppEdge("client", "datascheduler", 3500, 500, "_SERTIME", Tuple.UP, AppEdge.MODULE);  
		application.addAppEdge("datascheduler", "gatewaymodule", 100, 1000, 1000, "VM_C", Tuple.UP, AppEdge.MODULE);  
		application.addAppEdge("datascheduler", "client", 14, 500, "Net_USg", Tuple.DOWN, AppEdge.MODULE);   
		application.addAppEdge("gatewaymodule", "client", 100, 28, 1000, "DataTransfer", Tuple.DOWN, AppEdge.MODULE);  
		application.addAppEdge("client", "DISPLAY", 1000, 500, "Tasks", Tuple.DOWN, AppEdge.ACTUATOR);   
		application.addAppEdge("client", "DISPLAY", 1000, 500, "TasksDone", Tuple.DOWN, AppEdge.ACTUATOR);   
		
		 
		application.addTupleMapping("client", "enduser", "_SERTIME", new FractionalSelectivity(0.9));  
		application.addTupleMapping("client", "Net_USg", "Tasks", new FractionalSelectivity(0.9));  
		application.addTupleMapping("datascheduler", "_SERTIME", "Net_USg", new FractionalSelectivity(0.9));  
		application.addTupleMapping("client", "DataTransfer", "TasksDone", new FractionalSelectivity(1.0));  
	
		 
		final AppLoop loop1 = new AppLoop(new ArrayList<String>(){{add("enduser");add("client");add("datascheduler");add("client");add("DISPLAY");}});
		List<AppLoop> loops = new ArrayList<AppLoop>(){{add(loop1);}};
		application.setLoops(loops);
		
		return application;
	}

}
