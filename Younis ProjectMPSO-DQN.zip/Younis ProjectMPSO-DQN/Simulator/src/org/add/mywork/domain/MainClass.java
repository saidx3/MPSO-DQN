package org.add.mywork.domain;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.power.PowerHost;

import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import org.cloudbus.cloudsim.sdn.overbooking.BwProvisionerOverbooking;
import org.cloudbus.cloudsim.sdn.overbooking.PeProvisionerOverbooking;
import org.fog.application.AppEdge;
import org.fog.application.AppLoop;
import org.fog.application.Application;
import org.fog.application.selectivity.FractionalSelectivity;
import org.fog.entities.Actuator;
import org.fog.entities.FogBroker;
import org.fog.entities.FogDevice;
import org.fog.entities.FogDeviceCharacteristics;
import org.fog.entities.Sensor;
import org.fog.entities.Tuple;

import org.fog.placement.ModuleMapping;
import org.fog.placement.ModulePlacementEdgewards;
import org.fog.placement.ModulePlacementMapping;
import org.fog.policy.AppModuleAllocationPolicy;
import org.fog.scheduler.StreamOperatorScheduler;
import org.fog.utils.FogLinearPowerModel;
import org.fog.utils.FogUtils;
import org.fog.utils.GeoCoverage;
import org.fog.utils.TimeKeeper;
import org.fog.utils.distribution.DeterministicDistribution;


public class MainClass {
	static List<Integer> idOfEndDevices = new ArrayList<Integer>(); 
	static Map<Integer, Map<String, Double>> DataInfo = new 
	HashMap<Integer, Map<String, Double>>();
	static List<FogDevice> fogDevices = new ArrayList<FogDevice>();
	static List<Sensor> sensors = new ArrayList<Sensor>();
	static List<Actuator> actuators = new ArrayList<Actuator>();
	static boolean CLOUD = true;
    static Application application ;

    public static String status="null";
 

	
	public static void main(String[] args) {
	
          
		

		try {
			Log.disable();
			
			String appId = "CLOUD-COST-AWARE-SYSTEM"; 
			Calendar calendar = Calendar.getInstance();
			boolean trace_flag = false; 

			CloudSim.init(1, calendar, trace_flag);

		
			
			FogBroker broker = new FogBroker("broker");
			Loaddataclass obj=new Loaddataclass();	
	
			application= obj.createApplication(appId, broker.getId());
			application.setUserId(broker.getId());
			
			createFogDevices(broker.getId(), appId);
			
			ModuleMapping moduleMapping = ModuleMapping.createModuleMapping(); 
			
			if(CLOUD){
				
				moduleMapping.addModuleToDevice("gatewaymodule", "cloud"); 
					moduleMapping.addModuleToDevice("datasetmodule", "cloud"); 
					for(FogDevice device : fogDevices){
						if(device.getName().startsWith("ResourceManager")){
							
							moduleMapping.addModuleToDevice("client", device.getName());  
						}
					}
				}
				else{
					
					
					moduleMapping.addModuleToDevice("gatewaymodule", "cloud"); 
					
				}
			
			Simulator controller = new Simulator("new-controller", fogDevices, sensors, 
					actuators);
			
			controller.submitApplication(application, 1, 
					(CLOUD)?(new ModulePlacementMapping(fogDevices, application, moduleMapping))
							:(new ModulePlacementEdgewards(fogDevices, sensors, actuators, application, moduleMapping)));
		}
		catch (Exception ex) {
				
				ex.printStackTrace();
				
			}
		
		JOptionPane.showMessageDialog(null, "Processing... Please wait.");
			
	 StartApp();
	}

	 
	private static void createFogDevices(int clientId, String appId) {
		FogDevice cloud = createFogDevice("cloud", 40000, 20000, 100, 5000, 0, 0.01, 5*100.45, 5*80.25); 
		cloud.setParentId(-1);
		FogDevice gateway = createFogDevice("gateway-server", 2000, 1000, 5000, 5000, 1, 0.0, 100.45, 80.25); 
		gateway.setParentId(cloud.getId()); 
		gateway.setUplinkLatency(100); 
		
		fogDevices.add(cloud);
		fogDevices.add(gateway);
		
		
		for(int i=0;i<2;i++){
			TaskSchedulerMnodes(i+"", clientId, appId, gateway.getId()); 
		}
		
	}

	private static FogDevice TaskSchedulerMnodes(String id, int clientId, String appId, int parentId){
		FogDevice fns = createFogDevice("TaskScheduler"+id, 10000, 10000, 1000, 5000, 2, 0.1, 100.45, 80.25);
		fogDevices.add(fns);
		fns.setParentId(parentId);
		fns.setUplinkLatency(10); 
	
		for(int i=0;i<2;i++){
			String sendeviceId = id+"-"+i;
			FogDevice sendevice = SetEdges(sendeviceId, clientId, appId, fns.getId()); 
			sendevice.setUplinkLatency(10); 
			fogDevices.add(sendevice);
		}
		return fns;
	}
	public static void StartApp() {
		
		
		

		
	} 
	
		
	
	
	private static FogDevice SetEdges(String id, int clientId, String appId, int parentId){
		FogDevice sendevice = createFogDevice("ResourceManager", 10000, 5000, 2000, 5000, 3, 0.1, 87.53, 82.44);
		sendevice.setParentId(parentId);
		Sensor settype = new Sensor("s-", "enduser", clientId, appId, new DeterministicDistribution(4.1)); 
		sensors.add(settype);
		Actuator display = new Actuator("display-", clientId, appId, "DISPLAY");
		actuators.add(display);
		settype.setGatewayDeviceId(sendevice.getId());
		settype.setLatency(9.0);  
		display.setGatewayDeviceId(sendevice.getId());
		display.setLatency(5.0);  
		return sendevice;
	}
	
	 
	private static FogDevice createFogDevice(String nodeName, long mips,
			int ram, long upBw, long downBw, int level, double ratePerMips, double busyPower, double idlePower) {
		
		List<Pe> peList = new ArrayList<Pe>();

		
		peList.add(new Pe(0, new PeProvisionerOverbooking(mips))); 

		int hostId = FogUtils.generateEntityId();
		long storage = 1000000; 
		int bw = 10000;

		PowerHost host = new PowerHost(
				hostId,
				new RamProvisionerSimple(ram),
				new BwProvisionerOverbooking(bw),
				storage,
				peList,
				new StreamOperatorScheduler(peList),
				new FogLinearPowerModel(busyPower, idlePower)
			);

		List<Host> hostList = new ArrayList<Host>();
		hostList.add(host);

		String arch = "x86"; 
		String os = "Linux"; 
		String vmm = "Xen";
		double time_zone = 10.0; 
		double cost = 3.0; 
		double costPerMem = 0.05; 
		double costPerStorage = 0.001; 
										
		double costPerBw = 0.0; 
		LinkedList<Storage> storageList = new LinkedList<Storage>(); 
													

		FogDeviceCharacteristics characteristics = new FogDeviceCharacteristics(
				arch, os, vmm, host, time_zone, cost, costPerMem,
				costPerStorage, costPerBw);

		FogDevice fogdevice = null;
		try {
			fogdevice = new FogDevice(nodeName, characteristics, 
					new AppModuleAllocationPolicy(hostList), storageList, 10, upBw, downBw, 0, ratePerMips);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		fogdevice.setLevel(level);
		return fogdevice;
	}


	
	
}
