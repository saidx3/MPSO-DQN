package org.add.mywork.domain;


import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.ResCloudlet;

public class Scheduling extends CloudletSchedulerTimeShared{

	public Scheduling(double mips, int numberOfPes) {
		
		super();
	}


	public double getEstimatedFinishTime(ResCloudlet rcl, double time) {
		System.out.println("REMAINING CLOUDLET LENGTH : "+rcl.getRemainingCloudletLength()+"\tCLOUDLET LENGTH"+rcl.getCloudletLength());
		System.out.println("CURRENT ALLOC MIPS FOR CLOUDLET : "+getTotalCurrentAllocatedMipsForCloudlet(rcl, time));
		
		
		System.out.println("ALLOCATED MIPS FOR CLOUDLET = "+getTotalCurrentAllocatedMipsForCloudlet(rcl, time));
		return time
				+ ((rcl.getRemainingCloudletLength()) / getTotalCurrentAllocatedMipsForCloudlet(rcl, time));
		
		
				
	}
	
public void cloudletFinish(ResCloudlet rcl) {
	rcl.setCloudletStatus(Cloudlet.SUCCESS);		rcl.finalizeCloudlet();
		getCloudletFinishedList().add(rcl);
	}
	
}
