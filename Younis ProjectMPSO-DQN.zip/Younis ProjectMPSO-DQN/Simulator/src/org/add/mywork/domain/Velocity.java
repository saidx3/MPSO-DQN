package org.add.mywork.domain;

public class Velocity {

}
